create view view_name as
select * from Users
go

